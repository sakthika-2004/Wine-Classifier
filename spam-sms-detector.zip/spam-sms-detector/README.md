# 📩 Spam SMS Detector

A simple **NLP / text classification** project that detects spam SMS messages using **TF-IDF** features and a **Multinomial Naive Bayes** classifier, with a **Streamlit** web demo.

## Features
- Text vectorization with TF-IDF (unigrams + bigrams, stop-word removal)
- Naive Bayes classifier compared against Logistic Regression
- Evaluation with precision, recall and F1-score, confusion matrix, and a chart of the top spam-indicating words
- Interactive Streamlit app: paste a message, get a spam probability

## Project structure
```
spam-sms-detector/
├── app.py                # Streamlit demo
├── train.py              # train, evaluate, save model and plots
├── download_data.py      # downloads the real SMS Spam Collection dataset
├── make_sample_data.py   # generates a small synthetic demo dataset
├── data/sample_sms.csv   # tiny synthetic dataset so the project runs instantly
└── requirements.txt
```

## Quick start

```bash
git clone https://github.com/<your-username>/spam-sms-detector.git
cd spam-sms-detector
pip install -r requirements.txt
```

**Option A: instant demo (small synthetic data)**
```bash
python train.py
streamlit run app.py
```

**Option B: real dataset (recommended for meaningful results)**
```bash
python download_data.py     # saves data/sms.csv (~5,500 real messages)
python train.py             # automatically uses data/sms.csv when present
streamlit run app.py
```

Training saves the model to `model/` and the plots to `outputs/`.

> The bundled `sample_sms.csv` is synthetic and very easy to classify, so its scores (near 100%) are not representative. Use the real dataset to measure true performance.

## How it works
1. **Load** messages labelled `ham` (normal) or `spam`
2. **Vectorize** text with TF-IDF so each message becomes a weighted word-frequency vector
3. **Train** Multinomial Naive Bayes, which estimates how likely each word is to appear in spam vs ham
4. **Predict** the spam probability for new messages

## Tech stack
Python · scikit-learn · pandas · NumPy · matplotlib · Streamlit

## Ideas to extend
- Add text cleaning (remove numbers, URLs) and compare its effect
- Try a pretrained Transformer model and compare with Naive Bayes
- Deploy the app for free on Streamlit Community Cloud

## License
MIT
