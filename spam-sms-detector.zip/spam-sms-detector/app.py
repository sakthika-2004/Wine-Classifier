"""Streamlit demo: paste an SMS and get a spam / not-spam prediction."""
from pathlib import Path

import joblib
import streamlit as st

st.set_page_config(page_title="Spam SMS Detector", page_icon="📩")
st.title("📩 Spam SMS Detector")
st.caption("TF-IDF + Multinomial Naive Bayes")

MODEL_PATH = Path("model/spam_model.joblib")
if not MODEL_PATH.exists():
    st.error("Model not found. Run `python train.py` first, then restart this app.")
    st.stop()

model = joblib.load(MODEL_PATH)

examples = {
    "Spam example": "WINNER!! You have won a free holiday trip. Call 09061701461 now to claim your prize!",
    "Normal example": "Hey, are we still meeting for lunch at noon?",
}
choice = st.selectbox("Try an example (optional)", ["-"] + list(examples))
default = examples.get(choice, "")
text = st.text_area("Enter an SMS message", value=default, height=120)

if st.button("Check message", type="primary"):
    if not text.strip():
        st.warning("Please enter a message.")
    else:
        proba = model.predict_proba([text])[0][1]
        if proba >= 0.5:
            st.error(f"🚨 Spam ({proba:.1%} confidence)")
        else:
            st.success(f"✅ Not spam ({1 - proba:.1%} confidence)")
        st.progress(float(proba), text=f"Spam probability: {proba:.1%}")
