"""Download the public SMS Spam Collection dataset into data/sms.csv."""
import io
import urllib.request
from pathlib import Path

import pandas as pd

URL = "https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv"


def main():
    print("Downloading SMS Spam Collection ...")
    raw = urllib.request.urlopen(URL, timeout=30).read().decode("utf-8")
    df = pd.read_csv(io.StringIO(raw), sep="\t", header=None, names=["label", "text"])
    Path("data").mkdir(exist_ok=True)
    df.to_csv("data/sms.csv", index=False)
    print(f"Saved data/sms.csv with {len(df)} messages")
    print(df["label"].value_counts())


if __name__ == "__main__":
    main()
