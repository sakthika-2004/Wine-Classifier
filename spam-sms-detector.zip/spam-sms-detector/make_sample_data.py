"""Generate a small synthetic demo dataset (data/sample_sms.csv).

This is ONLY for a quick demo. For real results, run `python download_data.py`
to fetch the public SMS Spam Collection dataset.
"""
import random
import pandas as pd

random.seed(42)

spam_templates = [
    "WINNER!! You have won a {prize}. Call {num} now to claim your prize!",
    "Congratulations! You've been selected for a free {prize}. Reply YES to claim.",
    "URGENT! Your account has been suspended. Verify now at {url} to avoid closure.",
    "FREE entry in our weekly draw to win a {prize}. Text WIN to {short} now!",
    "Limited offer: get {pct}% off today only! Click {url} to buy now.",
    "You have been pre-approved for a loan of {amt}. Apply now at {url}.",
    "Claim your free {prize} today! Offer expires tonight. Call {num}.",
    "Your mobile number has won {amt} in our lucky draw. Call {num} to collect.",
    "Hot singles in your area want to chat. Text JOIN to {short}. Msgs cost 50p.",
    "ALERT: unusual activity detected on your bank account. Confirm details at {url}.",
]
ham_templates = [
    "Hey, are we still meeting for {meal} at {time}?",
    "Can you pick up some {item} on your way home?",
    "I'll be late, the {transport} is delayed. Start without me.",
    "Happy birthday! Hope you have a wonderful day with family.",
    "Did you finish the {work}? The deadline is tomorrow morning.",
    "Thanks for helping me yesterday, I really appreciate it.",
    "Call me when you get free, I wanted to talk about the weekend plan.",
    "Don't forget {item} for the trip tomorrow. We leave at {time}.",
    "Lol that movie was so funny, we should watch the next one together.",
    "Mom says dinner is ready. Come home soon.",
    "The meeting has moved to {time}. Please bring the {work}.",
    "Good morning! Have a great day at college today.",
]
fills = dict(
    prize=["iPhone 15", "holiday trip", "cash prize of 5000", "gift voucher", "new laptop"],
    num=["09061701461", "08712460324", "0800 542 0578", "09050000332"],
    url=["bit.ly/claim-now", "secure-bank-login.xyz", "www.win-big.biz", "tinyurl.com/offer77"],
    short=["80086", "87121", "85023", "81010"],
    pct=["50", "70", "90"],
    amt=["Rs 50,000", "$1000", "Rs 2 lakh", "$5000"],
    meal=["lunch", "dinner", "coffee", "breakfast"],
    time=["5pm", "7:30", "noon", "6 o'clock", "8am"],
    item=["milk", "vegetables", "charger", "tickets", "umbrella"],
    transport=["bus", "train", "metro"],
    work=["report", "assignment", "slides", "project file"],
)

def fill(t):
    class D(dict):
        def __missing__(self, k):
            return "{" + k + "}"
    return t.format_map(D({k: random.choice(v) for k, v in fills.items()}))

rows = []
for _ in range(150):
    rows.append(("spam", fill(random.choice(spam_templates))))
for _ in range(300):
    rows.append(("ham", fill(random.choice(ham_templates))))
random.shuffle(rows)
pd.DataFrame(rows, columns=["label", "text"]).drop_duplicates().to_csv("data/sample_sms.csv", index=False)
print("Wrote data/sample_sms.csv")
