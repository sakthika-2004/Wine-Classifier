"""Train a TF-IDF + Naive Bayes spam classifier and save evaluation plots."""
import argparse
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import ConfusionMatrixDisplay, classification_report, f1_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

OUT = Path("outputs")
MODEL_DIR = Path("model")


def find_data(path):
    if path:
        return Path(path)
    for candidate in ("data/sms.csv", "data/sample_sms.csv"):
        if Path(candidate).exists():
            return Path(candidate)
    raise FileNotFoundError("No dataset found. Run `python download_data.py` first.")


def make_pipeline(clf):
    return Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), min_df=1)),
        ("clf", clf),
    ])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", help="Path to CSV with columns: label (ham/spam), text")
    args = parser.parse_args()

    data_path = find_data(args.data)
    df = pd.read_csv(data_path).dropna()
    print(f"Using {data_path}: {len(df)} messages\n{df['label'].value_counts().to_string()}\n")

    y = (df["label"] == "spam").astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], y, test_size=0.2, stratify=y, random_state=42
    )

    models = {
        "Naive Bayes": make_pipeline(MultinomialNB(alpha=0.1)),
        "Logistic Regression": make_pipeline(LogisticRegression(max_iter=1000, class_weight="balanced")),
    }

    scores = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        scores[name] = f1_score(y_test, model.predict(X_test))
        print(f"{name}: spam F1 = {scores[name]:.3f}")

    nb = models["Naive Bayes"]
    preds = nb.predict(X_test)
    print("\nNaive Bayes classification report:\n")
    print(classification_report(y_test, preds, target_names=["ham", "spam"]))

    OUT.mkdir(exist_ok=True)
    MODEL_DIR.mkdir(exist_ok=True)

    # Confusion matrix
    fig, ax = plt.subplots(figsize=(5, 4))
    ConfusionMatrixDisplay.from_predictions(
        y_test, preds, display_labels=["ham", "spam"], cmap="Blues", ax=ax
    )
    ax.set_title("Confusion Matrix - Naive Bayes")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150)

    # Top spam words
    vec, clf = nb.named_steps["tfidf"], nb.named_steps["clf"]
    words = np.array(vec.get_feature_names_out())
    diff = clf.feature_log_prob_[1] - clf.feature_log_prob_[0]
    top = np.argsort(diff)[-15:]
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.barh(words[top], diff[top], color="#c44e52")
    ax.set_title("Top words/phrases indicating spam")
    ax.set_xlabel("log-probability ratio (spam vs ham)")
    fig.tight_layout()
    fig.savefig(OUT / "top_spam_words.png", dpi=150)

    joblib.dump(nb, MODEL_DIR / "spam_model.joblib")
    print(f"Saved model to {MODEL_DIR}/ and plots to {OUT}/")


if __name__ == "__main__":
    main()
