# 🍷 Wine Classifier

A simple end-to-end **AI & Data Science** project: classify wines into 3 cultivars using their chemical properties, comparing three machine learning models.

## What it does
- Loads the built-in scikit-learn **Wine dataset** (178 samples, 13 features), so there is nothing to download
- Trains and compares **Logistic Regression**, **SVM (RBF)** and **Random Forest**
- Evaluates with 5-fold cross-validation and a held-out test set
- Generates a confusion matrix, feature importance chart and results table
- Saves the best model with `joblib`

## Results

| Model | CV Accuracy | Test Accuracy |
|---|---|---|
| Random Forest | 0.986 | 1.000 |
| Logistic Regression | 0.993 | 0.972 |
| SVM (RBF) | 0.986 | 0.972 |

Note: the dataset is small (36 test samples), so differences between models are not statistically meaningful.

![Confusion Matrix](outputs/confusion_matrix.png)
![Feature Importance](outputs/feature_importance.png)

## Run it

```bash
git clone https://github.com/<your-username>/wine-classifier.git
cd wine-classifier
pip install -r requirements.txt
python train.py
```

Outputs are saved in the `outputs/` folder.

## Tech stack
Python · scikit-learn · pandas · matplotlib

## Ideas to extend
- Hyperparameter tuning with `GridSearchCV`
- Add SHAP explanations
- Build a Streamlit app for live predictions
