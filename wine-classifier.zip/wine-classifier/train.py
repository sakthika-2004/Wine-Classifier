"""Wine Classifier: compare ML models on the scikit-learn Wine dataset."""
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.datasets import load_wine
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score, classification_report
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)


def main():
    # 1. Load data
    data = load_wine(as_frame=True)
    X, y = data.data, data.target
    print(f"Dataset: {X.shape[0]} samples, {X.shape[1]} features, classes: {list(data.target_names)}")

    # 2. Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    # 3. Define models
    models = {
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
        "SVM (RBF)": make_pipeline(StandardScaler(), SVC()),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
    }

    # 4. Train & evaluate
    results = []
    for name, model in models.items():
        cv = cross_val_score(model, X_train, y_train, cv=5).mean()
        model.fit(X_train, y_train)
        acc = accuracy_score(y_test, model.predict(X_test))
        results.append({"Model": name, "CV Accuracy": round(cv, 3), "Test Accuracy": round(acc, 3)})

    df = pd.DataFrame(results).sort_values("Test Accuracy", ascending=False)
    print("\n", df.to_string(index=False))
    df.to_csv(OUT / "results.csv", index=False)

    # 5. Best model report + confusion matrix
    best_name = df.iloc[0]["Model"]
    best = models[best_name]
    preds = best.predict(X_test)
    print(f"\nBest model: {best_name}\n")
    print(classification_report(y_test, preds, target_names=data.target_names))

    fig, ax = plt.subplots(figsize=(5, 4))
    ConfusionMatrixDisplay.from_predictions(
        y_test, preds, display_labels=data.target_names, cmap="Blues", ax=ax
    )
    ax.set_title(f"Confusion Matrix - {best_name}")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150)

    # 6. Feature importance (Random Forest)
    rf = models["Random Forest"]
    imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values()
    fig, ax = plt.subplots(figsize=(6, 5))
    imp.plot.barh(ax=ax, color="#4c72b0")
    ax.set_title("Feature Importance (Random Forest)")
    fig.tight_layout()
    fig.savefig(OUT / "feature_importance.png", dpi=150)

    # 7. Save best model
    joblib.dump(best, OUT / "best_model.joblib")
    print(f"Saved results, plots and model to ./{OUT}/")


if __name__ == "__main__":
    main()
